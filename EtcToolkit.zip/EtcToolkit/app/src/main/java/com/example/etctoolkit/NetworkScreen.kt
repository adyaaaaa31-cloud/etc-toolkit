package com.example.etctoolkit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun NetworkScreen(pad: PaddingValues) {
    var text by rememberSaveable { mutableStateOf("10k, 4.7k, 220") }

    val tokens = text.split(Regex("[\\s,;]+")).filter { it.isNotBlank() }
    val parsed = tokens.map { parseSI(it) }
    val nums = parsed.filterNotNull()

    Column(
        modifier = Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Series and parallel", style = MaterialTheme.typography.titleMedium)
        SiField("Resistor values, separated by commas", text, Modifier.fillMaxWidth()) { text = it }

        if (tokens.isEmpty()) {
            Text(
                "Type resistor values separated by commas, like 10k, 4.7k, 220.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else if (nums.size != tokens.size) {
            Text(
                "Could not read one of the values. Use numbers like 4.7k or 220.",
                color = MaterialTheme.colorScheme.error
            )
        } else {
            val series = nums.sum()
            val parallel = if (nums.any { it == 0.0 }) 0.0 else 1.0 / nums.sumOf { 1.0 / it }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ResultRow("Series", fmtSI(series, OHM))
                    ResultRow("Parallel", fmtSI(parallel, OHM))
                }
            }
            Text(
                "${nums.size} resistor(s)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
