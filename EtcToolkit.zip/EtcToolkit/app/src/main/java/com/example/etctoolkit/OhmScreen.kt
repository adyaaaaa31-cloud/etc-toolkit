package com.example.etctoolkit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private fun readField(s: String): Double? = if (s.isBlank()) null else parseSI(s)

@Composable
fun OhmScreen(pad: PaddingValues) {
    var v by rememberSaveable { mutableStateOf("5") }
    var i by rememberSaveable { mutableStateOf("") }
    var r by rememberSaveable { mutableStateOf("220") }
    var p by rememberSaveable { mutableStateOf("") }

    val pv = readField(v)
    val pi = readField(i)
    val pr = readField(r)
    val pp = readField(p)

    val unreadable = ArrayList<String>()
    if (v.isNotBlank() && pv == null) unreadable.add("Voltage")
    if (i.isNotBlank() && pi == null) unreadable.add("Current")
    if (r.isNotBlank() && pr == null) unreadable.add("Resistance")
    if (p.isNotBlank() && pp == null) unreadable.add("Power")
    val given = listOfNotNull(pv, pi, pr, pp).size
    val result = solveOhm(pv, pi, pr, pp)

    Column(
        modifier = Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Ohm's law", style = MaterialTheme.typography.titleMedium)
        Text(
            "Fill in any two values. Suffixes work: p, n, u (micro), m (milli), k, M, G.",
            style = MaterialTheme.typography.bodyMedium
        )

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SiField("Voltage (V)", v, Modifier.weight(1f)) { v = it }
            SiField("Current (A)", i, Modifier.weight(1f)) { i = it }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SiField("Resistance ($OHM)", r, Modifier.weight(1f)) { r = it }
            SiField("Power (W)", p, Modifier.weight(1f)) { p = it }
        }

        if (unreadable.isNotEmpty()) {
            Text(
                "Could not read: ${unreadable.joinToString(", ")}. Use numbers like 4.7k, 10m or 2u.",
                color = MaterialTheme.colorScheme.error
            )
        } else if (given < 2) {
            Text("Fill in any two values. The other two are calculated.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (given > 2) {
            Text("Fill in exactly two values. Clear the others.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (result == null) {
            Text("That combination cannot be calculated (division by zero).", color = MaterialTheme.colorScheme.error)
        } else {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ResultRow("Voltage", fmtSI(result.v, "V"))
                    ResultRow("Current", fmtSI(result.i, "A"))
                    ResultRow("Resistance", fmtSI(result.r, OHM))
                    ResultRow("Power", fmtSI(result.p, "W"))
                }
            }
        }
    }
}

@Composable
fun ResultRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}
