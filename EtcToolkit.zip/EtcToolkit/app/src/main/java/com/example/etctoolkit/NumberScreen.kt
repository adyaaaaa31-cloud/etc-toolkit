package com.example.etctoolkit

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.math.BigInteger

@Composable
fun NumberScreen(pad: PaddingValues) {
    var text by rememberSaveable { mutableStateOf("255") }
    var radix by rememberSaveable { mutableIntStateOf(10) }

    val clean = text.filter { !it.isWhitespace() }
    val valid = clean.isNotEmpty() && clean.all { Character.digit(it, radix) >= 0 }
    val n: BigInteger? = if (valid) BigInteger(clean, radix) else null

    Column(
        modifier = Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Number converter", style = MaterialTheme.typography.titleMedium)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("BIN", radix == 2, Modifier.weight(1f)) { radix = 2 }
            ChoiceButton("OCT", radix == 8, Modifier.weight(1f)) { radix = 8 }
            ChoiceButton("DEC", radix == 10, Modifier.weight(1f)) { radix = 10 }
            ChoiceButton("HEX", radix == 16, Modifier.weight(1f)) { radix = 16 }
        }

        SiField("Your number", text, Modifier.fillMaxWidth()) { text = it }

        if (clean.isEmpty()) {
            Text("Type a number in the base you picked.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else if (n == null) {
            Text("Those digits are not valid in base $radix.", color = MaterialTheme.colorScheme.error)
        } else {
            val bin = n.toString(2)
            val padded = bin.padStart(((bin.length + 3) / 4) * 4, '0')
            val grouped = padded.chunked(4).joinToString(" ")
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    ResultRow("Binary", grouped)
                    ResultRow("Octal", n.toString(8))
                    ResultRow("Decimal", n.toString(10))
                    ResultRow("Hex", n.toString(16).uppercase())
                }
            }
            Text(
                "${bin.length} bit(s)",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
