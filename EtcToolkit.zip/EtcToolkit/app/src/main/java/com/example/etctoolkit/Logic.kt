package com.example.etctoolkit

import androidx.compose.ui.graphics.Color
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToLong
import kotlin.math.sqrt

/** One colour of the resistor colour code. digit, mult and tol are null when the colour cannot be used for that role. */
class Band(val name: String, val color: Color, val digit: Int?, val mult: Double?, val tol: Double?)

/** Index 0..9 are the digit colours, 10 is Gold and 11 is Silver. */
val BANDS: List<Band> = listOf(
    Band("Black", Color(0xFF111111), 0, 1.0, null),
    Band("Brown", Color(0xFF6B3E1F), 1, 10.0, 1.0),
    Band("Red", Color(0xFFD32F2F), 2, 100.0, 2.0),
    Band("Orange", Color(0xFFF57C00), 3, 1e3, null),
    Band("Yellow", Color(0xFFFBC02D), 4, 1e4, null),
    Band("Green", Color(0xFF388E3C), 5, 1e5, 0.5),
    Band("Blue", Color(0xFF1976D2), 6, 1e6, 0.25),
    Band("Violet", Color(0xFF7B1FA2), 7, 1e7, 0.1),
    Band("Grey", Color(0xFF757575), 8, 1e8, 0.05),
    Band("White", Color(0xFFF5F5F5), 9, 1e9, null),
    Band("Gold", Color(0xFFC9A227), null, 0.1, 5.0),
    Band("Silver", Color(0xFFB0B0B0), null, 0.01, 10.0)
)

val DIGIT_OPTIONS: List<Int> = listOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
val MULT_OPTIONS: List<Int> = listOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)
val TOL_OPTIONS: List<Int> = listOf(1, 2, 5, 6, 7, 8, 10, 11)

const val OHM = "Ω"

private val SI_REGEX = Regex("^\\s*([0-9]*\\.?[0-9]+(?:[eE][+-]?[0-9]+)?)\\s*([pnumkKMG]?)\\s*$")

/** Reads numbers like 4.7k, 10m, 2u, 1M. Returns null when the text is not a number. */
fun parseSI(text: String): Double? {
    val m = SI_REGEX.matchEntire(text) ?: return null
    val base = m.groupValues[1].toDoubleOrNull() ?: return null
    val mult = when (m.groupValues[2]) {
        "p" -> 1e-12
        "n" -> 1e-9
        "u" -> 1e-6
        "m" -> 1e-3
        "k" -> 1e3
        "K" -> 1e3
        "M" -> 1e6
        "G" -> 1e9
        else -> 1.0
    }
    return base * mult
}

/** Writes a value with an engineering prefix, for example 4700.0 and "OHM" give "4.7 kOHM". */
fun fmtSI(x: Double, unit: String): String {
    if (x.isNaN() || x.isInfinite()) return "--"
    if (x == 0.0) return "0 $unit"
    var e = (floor(log10(abs(x)) / 3.0) * 3).toInt()
    if (e < -12) e = -12
    if (e > 9) e = 9
    val scaled = x / 10.0.pow(e)
    val s = "%.2f".format(scaled).trimEnd('0').trimEnd('.')
    val prefix = when (e) {
        -12 -> "p"
        -9 -> "n"
        -6 -> "µ"
        -3 -> "m"
        3 -> "k"
        6 -> "M"
        9 -> "G"
        else -> ""
    }
    return "$s $prefix$unit"
}

/**
 * Colour bands (digit bands then multiplier) for a resistance, or null if it cannot be shown.
 * digits is 2 for a 4-band resistor and 3 for a 5-band resistor.
 */
fun bandsForValue(v: Double, digits: Int): List<Int>? {
    if (v.isNaN() || v.isInfinite() || v <= 0.0) return null
    val lo = 10.0.pow(digits - 1).roundToLong()
    val hi = 10.0.pow(digits).roundToLong()
    var e = floor(log10(v)).toInt() - (digits - 1)
    var d = (v / 10.0.pow(e)).roundToLong()
    if (d < lo) {
        e -= 1
        d = (v / 10.0.pow(e)).roundToLong()
    }
    if (d >= hi) {
        d /= 10
        e += 1
    }
    if (e < -2 || e > 9) return null
    if (abs(d * 10.0.pow(e) - v) / v > 1e-6) return null
    val out = mutableListOf<Int>()
    for (ch in d.toString().padStart(digits, '0')) {
        out.add(ch - '0')
    }
    out.add(if (e >= 0) e else if (e == -1) 10 else 11)
    return out
}

data class Ohm(val v: Double, val i: Double, val r: Double, val p: Double)

/** Needs exactly two non-null values. Returns null if that is not so or the maths would divide by zero. */
fun solveOhm(v: Double?, i: Double?, r: Double?, p: Double?): Ohm? {
    if (listOfNotNull(v, i, r, p).size != 2) return null
    return when {
        v != null && i != null -> if (i == 0.0) null else Ohm(v, i, v / i, v * i)
        v != null && r != null -> if (r == 0.0) null else Ohm(v, v / r, r, v * v / r)
        v != null && p != null -> if (v == 0.0 || p == 0.0) null else Ohm(v, p / v, v * v / p, p)
        i != null && r != null -> Ohm(i * r, i, r, i * i * r)
        i != null && p != null -> if (i == 0.0) null else Ohm(p / i, i, p / (i * i), p)
        r != null && p != null -> if (r <= 0.0 || p < 0.0) null else Ohm(sqrt(p * r), sqrt(p / r), r, p)
        else -> null
    }
}
