package com.example.etctoolkit

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun ResistorScreen(pad: PaddingValues) {
    var fiveBand by rememberSaveable { mutableStateOf(false) }
    var d1 by rememberSaveable { mutableIntStateOf(4) }
    var d2 by rememberSaveable { mutableIntStateOf(7) }
    var d3 by rememberSaveable { mutableIntStateOf(0) }
    var mult by rememberSaveable { mutableIntStateOf(2) }
    var tol by rememberSaveable { mutableIntStateOf(10) }
    var valueText by rememberSaveable { mutableStateOf("4.7k") }

    val shown = if (fiveBand) listOf(d1, d2, d3, mult, tol) else listOf(d1, d2, mult, tol)
    val number: Int = if (fiveBand) {
        (BANDS[d1].digit ?: 0) * 100 + (BANDS[d2].digit ?: 0) * 10 + (BANDS[d3].digit ?: 0)
    } else {
        (BANDS[d1].digit ?: 0) * 10 + (BANDS[d2].digit ?: 0)
    }
    val value: Double = number * (BANDS[mult].mult ?: 1.0)
    val tolPct: Double = BANDS[tol].tol ?: 5.0

    Column(
        modifier = Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Resistor colour code", style = MaterialTheme.typography.titleMedium)

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("4 bands", !fiveBand, Modifier.weight(1f)) { fiveBand = false }
            ChoiceButton("5 bands", fiveBand, Modifier.weight(1f)) { fiveBand = true }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ResistorGraphic(shown)
                Text(
                    fmtSI(value, OHM),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "±$tolPct% (${fmtSI(value * (1 - tolPct / 100), OHM)} to ${fmtSI(value * (1 + tolPct / 100), OHM)})",
                    style = MaterialTheme.typography.bodySmall,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        BandPicker("Band 1", DIGIT_OPTIONS, d1) { d1 = it }
        BandPicker("Band 2", DIGIT_OPTIONS, d2) { d2 = it }
        if (fiveBand) BandPicker("Band 3", DIGIT_OPTIONS, d3) { d3 = it }
        BandPicker("Multiplier", MULT_OPTIONS, mult) { mult = it }
        BandPicker("Tolerance", TOL_OPTIONS, tol) { tol = it }

        Text("Value to colours", style = MaterialTheme.typography.titleMedium)
        SiField("Resistance in ohms, e.g. 4.7k, 220, 1M", valueText, Modifier.fillMaxWidth()) { valueText = it }

        val v = parseSI(valueText)
        val found = if (v == null) null else bandsForValue(v, if (fiveBand) 3 else 2)
        if (found == null) {
            Text(
                if (v == null) "Type a value like 4.7k, 220 or 1M." else "That value cannot be shown with this many bands.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            val all = found + 10
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                for (i in all) {
                    Box(
                        Modifier.size(28.dp)
                            .background(BANDS[i].color, CircleShape)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                    )
                }
            }
            Text(all.joinToString(", ") { BANDS[it].name } + " (last band is Gold, 5%)")
        }
    }
}

@Composable
private fun ResistorGraphic(bands: List<Int>) {
    Row(
        Modifier.fillMaxWidth().height(56.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(Modifier.width(32.dp).height(4.dp).background(Color(0xFF9AA0A8)))
        Row(
            Modifier.height(46.dp).background(Color(0xFFD9C59B), RoundedCornerShape(23.dp)).padding(horizontal = 26.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            for (i in bands) {
                Box(Modifier.width(12.dp).fillMaxHeight().background(BANDS[i].color))
            }
        }
        Box(Modifier.width(32.dp).height(4.dp).background(Color(0xFF9AA0A8)))
    }
}

@Composable
private fun BandPicker(title: String, options: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("$title: ${BANDS[selected].name}", style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            for (i in options) {
                val isSelected = i == selected
                Box(
                    Modifier.size(36.dp)
                        .background(BANDS[i].color, CircleShape)
                        .border(
                            if (isSelected) 3.dp else 1.dp,
                            if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                            CircleShape
                        )
                        .clickable { onPick(i) }
                )
            }
        }
    }
}
